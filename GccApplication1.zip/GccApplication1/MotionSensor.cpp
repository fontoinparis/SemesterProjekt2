#include "MotionSensor.h"
#include <avr/io.h>
#include <avr/interrupt.h>


MotionSensor::MotionSensor() {
	motionDetected = false;
	// Configure sensor pin as input
	DDRD &= ~(1 << PD2); // Assuming motion sensor is connected to pin PD2
	// Enable external interrupt INT0
	EICRA |= (1 << ISC00) | (1 << ISC01); // Any logical change on INT0 generates an interrupt
	EIMSK |= (1 << INT0);  // Enable external interrupt INT0
	// Enable global interrupts
	sei();
}

bool MotionSensor::isMotionDetected() {
	return motionDetected;
}

void MotionSensor::setMotionDetected(bool detected) {
	motionDetected = detected;
}
