/*
 * IncFile1.h
 *
 * Created: 12-05-2024 10:27:02
 *  Author: Fillip
 */ 

/*
 * IncFile1.h
 *
 * Created: 06-05-2024 13:08:52
 *  Author: Fillip
 */ 


/************************************************
* "uart.c":                                     *
* Implementation file for Mega2560 UART driver. *
* Using UART 0.                                 *
* Henning Hargaard                              *
*************************************************/


// Target CPU frequency
#define XTAL 16000000

void InitUART();
void SendString(char* Streng);

