/*
 * CPPFile1.cpp
 *
 * Created: 12-05-2024 10:26:54
 *  Author: Fillip
 */ 

/*
 * CPPFile1.cpp
 *
 * Created: 06-05-2024 13:17:57
 *  Author: Fillip
 */ 
#include <avr/io.h>
#include <stdlib.h>
#include "uart.h"

#include <avr/io.h> // Assuming AVR microcontroller

// Function to initialize UART 0
void InitUART() {
	// Set baud rate to 9600 (assuming 16MHz clock frequency)
	UBRR0H = 0;
	UBRR0L = 103;

	// Set data bits (8-bit)
	UCSR0C = (1 << UCSZ01) | (1 << UCSZ00);

	// Enable receiver and transmitter
	UCSR0B = (1 << RXEN0) | (1 << TXEN0);

	// Set number of stop bits (1 stop bit)
	UCSR0C &= ~(1 << USBS0);
}

// Function to transmit a string over UART 0
void SendString(char* Streng) {
	// Transmit each character of the string over UART
	while (*Streng != '\0') {
		// Wait for empty transmit buffer
		while (!(UCSR0A & (1 << UDRE0)));

		// Transmit data
		UDR0 = *Streng++;
	}
}


