#include <avr/io.h>
#include <avr/interrupt.h>
#include "MotionSensor.h"

MotionSensor motionSensor;

volatile bool BrugerIRum = false;

volatile bool sensorState = false;

// Interrupt service routine for INT0
ISR(INT0_vect) {
	if(!sensorState){
		
		BrugerIRum = true;
		motionSensor.setMotionDetected(true);
		sensorState = true;
	}
	
}

int main() {
	// Configure LED pin as output
	DDRB |= (1 << PB0); // Assuming LED is connected to pin PB0

	while (1) {
		if (BrugerIRum) {		
			PORTB |= (1 << PB0); // Turn on LED
			} else {				
			PORTB &= ~(1 << PB0); // Turn off LED
		}
		
		if(motionSensor.isMotionDetected()){
			motionSensor.setMotionDetected(false);
		}
	}
	return 0;
}


