#ifndef MOTIONSENSOR_H
#define MOTIONSENSOR_H

class MotionSensor {
	private:
	volatile bool motionDetected;

	public:
	MotionSensor();
	bool isMotionDetected();
	void setMotionDetected(bool detected);
};

#endif /* MOTIONSENSOR_H */
